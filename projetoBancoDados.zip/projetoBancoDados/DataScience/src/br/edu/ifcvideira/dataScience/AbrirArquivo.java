package br.edu.ifcvideira.dataScience;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.JOptionPane;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class AbrirArquivo {
	public static final String fileName = "C:/Users/Evandro Campos/Desktop/projetoBancoDados/DataScience/consulta.xls";
		
		public static void main(String[] args) {
			List<Anac> listAnac = new ArrayList<Anac>();
			int cont = 0; 
			
			FileInputStream arquivo = null;
			
			try {
				arquivo = new FileInputStream(new File(AbrirArquivo.fileName));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			HSSFWorkbook workbook = null;
			try {
				workbook = new HSSFWorkbook(arquivo);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			HSSFSheet sheetDados = workbook.getSheetAt(0);
			
			Iterator<Row> rowInterator = sheetDados.iterator();
			
			while(rowInterator.hasNext()) {
				cont++;
				Row row = rowInterator.next();
				Iterator<Cell> cellInterator = row.cellIterator();
				
				Anac anac = new Anac();
				listAnac.add(anac);
				
				while (cellInterator.hasNext()) {
					Cell cell = cellInterator.next();
					switch (cell.getColumnIndex()) {
					case 0:
						anac.setSigla(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 1:
						anac.setEmpresa(String.valueOf(cell.getCellComment()));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 2:
						anac.setNacionalidade(String.valueOf(cell.getCellComment()));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 3:
						if (String.valueOf(cell.getCellComment()) == "null") {
							anac.setAno(" ");
						}else {
							anac.setAno((String.valueOf(cell.getCellComment())));
						}
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 4:
						if (String.valueOf(cell.getCellComment()) == "null") {
							anac.setMes(" ");
						}else {
							anac.setMes((String.valueOf(cell.getCellComment())));
						}
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 5:
						if(String.valueOf(cell.getCellComment()) == "null") {
							anac.setAeroOrigemSigla("  ");
						}else {
							anac.setAeroOrigemSigla(cell.getStringCellValue());
						}
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 6:
						anac.setAeroOrigemNome(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 7:
						anac.setAeroOrigemUf(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 8:
						anac.setAeroOrigemRegiao(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 9:
						anac.setAeroOrigemPais(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 10:
						anac.setAeroOrigemContinente(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 11:
						anac.setAeroDestinoSigla(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 12:
						anac.setAeroDestinoNome(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 13:
						anac.setAeroDestinoUf(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 14:
						anac.setAeroDestinoRegiao(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 15:
						anac.setAeroDestinoPais(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 16:
						anac.setAeroDestinoContinente(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 17:
						anac.setNatureza(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 18:
						anac.setGrupoVoo(cell.getStringCellValue());
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 19:
						anac.setPassageirosPagos((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 20:
						anac.setPassageirosGratis((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 21:
						anac.setCargaPaga((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 22:
						anac.setCargaGratis((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 23:
						anac.setCorreio((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 24:
						anac.setCorreioKm((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 25:
						anac.setAsk((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 26:
						anac.setRpk((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 27:
						anac.setAtk((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 28:
						anac.setRtk((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 29:
						anac.setDistanciaVoado((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 30:
						anac.setDecolagens((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 31:
						anac.setCargaPagaKm((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 32:
						anac.setCargaGratis((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 33:
						anac.setCorreio((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 34:
						anac.setAssentos((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 35:
						anac.setPayload((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 36:
						anac.setHorasVoadas((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					case 37:
						anac.setBagagem((String.valueOf(cell.getNumericCellValue())));
						System.out.println("Cont: " + cont);
						cont++;
						break;
					}
				}
			}
			JOptionPane.showMessageDialog(null, "Processo Finalizado !" + cont, "Convers�o ", JOptionPane.INFORMATION_MESSAGE);
		}
}
