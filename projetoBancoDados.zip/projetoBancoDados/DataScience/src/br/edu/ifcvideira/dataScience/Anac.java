package br.edu.ifcvideira.dataScience;

public class Anac {
	
	private String sigla;
	private String empresa;
	private String nacionalidade;
	private String ano;
	private String mes;
	private String aeroOrigemSigla;
	private String aeroOrigemNome;
	private String aeroOrigemUf;
	private String aeroOrigemRegiao;
	private String aeroOrigemPais;
	private String aeroOrigemContinente;
	private String aeroDestinoSigla;
	private String aeroDestinoNome;
	private String aeroDestinoUf;
	private String aeroDestinoRegiao;
	private String aeroDestinoPais;
	private String aeroDestinoContinente;
	private String natureza;
	private String grupoVoo;
	private String passageirosPagos;
	private String passageirosGratis;
	private String cargaPaga;
	private String cargaGratis;
	private String correio;
	private String ask;
	private String rpk;
	private String atk;
	private String rtk;
	private String combustivelLitros;
	private String distanciaVoado;
	private String decolagens;
	private String cargaPagaKm;
	private String cargaGratisKm;
	private String correioKm;
	private String assentos;
	private String payload;
	private String horasVoadas;
	private String bagagem;
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public String getEmpresa() {
		return empresa;
	}
	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}
	public String getNacionalidade() {
		return nacionalidade;
	}
	public void setNacionalidade(String nacionalidade) {
		this.nacionalidade = nacionalidade;
	}
	public String getAno() {
		return ano;
	}
	public void setAno(String ano) {
		this.ano = ano;
	}
	public String getMes() {
		return mes;
	}
	public void setMes(String mes) {
		this.mes = mes;
	}
	public String getAeroOrigemSigla() {
		return aeroOrigemSigla;
	}
	public void setAeroOrigemSigla(String aeroOrigemSigla) {
		this.aeroOrigemSigla = aeroOrigemSigla;
	}
	public String getAeroOrigemNome() {
		return aeroOrigemNome;
	}
	public void setAeroOrigemNome(String aeroOrigemNome) {
		this.aeroOrigemNome = aeroOrigemNome;
	}
	public String getAeroOrigemUf() {
		return aeroOrigemUf;
	}
	public void setAeroOrigemUf(String aeroOrigemUf) {
		this.aeroOrigemUf = aeroOrigemUf;
	}
	public String getAeroOrigemRegiao() {
		return aeroOrigemRegiao;
	}
	public void setAeroOrigemRegiao(String aeroOrigemRegiao) {
		this.aeroOrigemRegiao = aeroOrigemRegiao;
	}
	public String getAeroOrigemPais() {
		return aeroOrigemPais;
	}
	public void setAeroOrigemPais(String aeroOrigemPais) {
		this.aeroOrigemPais = aeroOrigemPais;
	}
	public String getAeroOrigemContinente() {
		return aeroOrigemContinente;
	}
	public void setAeroOrigemContinente(String aeroOrigemContinente) {
		this.aeroOrigemContinente = aeroOrigemContinente;
	}
	public String getAeroDestinoSigla() {
		return aeroDestinoSigla;
	}
	public void setAeroDestinoSigla(String aeroDestinoSigla) {
		this.aeroDestinoSigla = aeroDestinoSigla;
	}
	public String getAeroDestinoNome() {
		return aeroDestinoNome;
	}
	public void setAeroDestinoNome(String aeroDestinoNome) {
		this.aeroDestinoNome = aeroDestinoNome;
	}
	public String getAeroDestinoUf() {
		return aeroDestinoUf;
	}
	public void setAeroDestinoUf(String aeroDestinoUf) {
		this.aeroDestinoUf = aeroDestinoUf;
	}
	public String getAeroDestinoRegiao() {
		return aeroDestinoRegiao;
	}
	public void setAeroDestinoRegiao(String aeroDestinoRegiao) {
		this.aeroDestinoRegiao = aeroDestinoRegiao;
	}
	public String getAeroDestinoPais() {
		return aeroDestinoPais;
	}
	public void setAeroDestinoPais(String aeroDestinoPais) {
		this.aeroDestinoPais = aeroDestinoPais;
	}
	public String getAeroDestinoContinente() {
		return aeroDestinoContinente;
	}
	public void setAeroDestinoContinente(String aeroDestinoContinente) {
		this.aeroDestinoContinente = aeroDestinoContinente;
	}
	public String getNatureza() {
		return natureza;
	}
	public void setNatureza(String natureza) {
		this.natureza = natureza;
	}
	public String getGrupoVoo() {
		return grupoVoo;
	}
	public void setGrupoVoo(String grupoVoo) {
		this.grupoVoo = grupoVoo;
	}
	public String getPassageirosPagos() {
		return passageirosPagos;
	}
	public void setPassageirosPagos(String passageirosPagos) {
		this.passageirosPagos = passageirosPagos;
	}
	public String getPassageirosGratis() {
		return passageirosGratis;
	}
	public void setPassageirosGratis(String passageirosGratis) {
		this.passageirosGratis = passageirosGratis;
	}
	public String getCargaPaga() {
		return cargaPaga;
	}
	public void setCargaPaga(String cargaPaga) {
		this.cargaPaga = cargaPaga;
	}
	public String getCargaGratis() {
		return cargaGratis;
	}
	public void setCargaGratis(String cargaGratis) {
		this.cargaGratis = cargaGratis;
	}
	public String getCorreio() {
		return correio;
	}
	public void setCorreio(String correio) {
		this.correio = correio;
	}
	public String getAsk() {
		return ask;
	}
	public void setAsk(String ask) {
		this.ask = ask;
	}
	public String getRpk() {
		return rpk;
	}
	public void setRpk(String rpk) {
		this.rpk = rpk;
	}
	public String getAtk() {
		return atk;
	}
	public void setAtk(String atk) {
		this.atk = atk;
	}
	public String getRtk() {
		return rtk;
	}
	public void setRtk(String rtk) {
		this.rtk = rtk;
	}
	public String getCombustivelLitros() {
		return combustivelLitros;
	}
	public void setCombustivelLitros(String combustivelLitros) {
		this.combustivelLitros = combustivelLitros;
	}
	public String getDistanciaVoado() {
		return distanciaVoado;
	}
	public void setDistanciaVoado(String distanciaVoado) {
		this.distanciaVoado = distanciaVoado;
	}
	public String getDecolagens() {
		return decolagens;
	}
	public void setDecolagens(String decolagens) {
		this.decolagens = decolagens;
	}
	public String getCargaPagaKm() {
		return cargaPagaKm;
	}
	public void setCargaPagaKm(String cargaPagaKm) {
		this.cargaPagaKm = cargaPagaKm;
	}
	public String getCargaGratisKm() {
		return cargaGratisKm;
	}
	public void setCargaGratisKm(String cargaGratisKm) {
		this.cargaGratisKm = cargaGratisKm;
	}
	public String getCorreioKm() {
		return correioKm;
	}
	public void setCorreioKm(String correioKm) {
		this.correioKm = correioKm;
	}
	public String getAssentos() {
		return assentos;
	}
	public void setAssentos(String assentos) {
		this.assentos = assentos;
	}
	public String getPayload() {
		return payload;
	}
	public void setPayload(String payload) {
		this.payload = payload;
	}
	public String getHorasVoadas() {
		return horasVoadas;
	}
	public void setHorasVoadas(String horasVoadas) {
		this.horasVoadas = horasVoadas;
	}
	public String getBagagem() {
		return bagagem;
	}
	public void setBagagem(String bagagem) {
		this.bagagem = bagagem;
	}
	
	public Anac() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Anac(String sigla, String empresa, String nacionalidade, String ano, String mes, String aeroOrigemSigla,
			String aeroOrigemNome, String aeroOrigemUf, String aeroOrigemRegiao, String aeroOrigemPais,
			String aeroOrigemContinente, String aeroDestinoSigla, String aeroDestinoNome, String aeroDestinoUf,
			String aeroDestinoRegiao, String aeroDestinoPais, String aeroDestinoContinente, String natureza,
			String grupoVoo, String passageirosPagos, String passageirosGratis, String cargaPaga, String cargaGratis,
			String correio, String ask, String rpk, String atk, String rtk, String combustivelLitros,
			String distanciaVoado, String decolagens, String cargaPagaKm, String cargaGratisKm, String correioKm,
			String assentos, String payload, String horasVoadas, String bagagem) {
		super();
		this.sigla = sigla;
		this.empresa = empresa;
		this.nacionalidade = nacionalidade;
		this.ano = ano;
		this.mes = mes;
		this.aeroOrigemSigla = aeroOrigemSigla;
		this.aeroOrigemNome = aeroOrigemNome;
		this.aeroOrigemUf = aeroOrigemUf;
		this.aeroOrigemRegiao = aeroOrigemRegiao;
		this.aeroOrigemPais = aeroOrigemPais;
		this.aeroOrigemContinente = aeroOrigemContinente;
		this.aeroDestinoSigla = aeroDestinoSigla;
		this.aeroDestinoNome = aeroDestinoNome;
		this.aeroDestinoUf = aeroDestinoUf;
		this.aeroDestinoRegiao = aeroDestinoRegiao;
		this.aeroDestinoPais = aeroDestinoPais;
		this.aeroDestinoContinente = aeroDestinoContinente;
		this.natureza = natureza;
		this.grupoVoo = grupoVoo;
		this.passageirosPagos = passageirosPagos;
		this.passageirosGratis = passageirosGratis;
		this.cargaPaga = cargaPaga;
		this.cargaGratis = cargaGratis;
		this.correio = correio;
		this.ask = ask;
		this.rpk = rpk;
		this.atk = atk;
		this.rtk = rtk;
		this.combustivelLitros = combustivelLitros;
		this.distanciaVoado = distanciaVoado;
		this.decolagens = decolagens;
		this.cargaPagaKm = cargaPagaKm;
		this.cargaGratisKm = cargaGratisKm;
		this.correioKm = correioKm;
		this.assentos = assentos;
		this.payload = payload;
		this.horasVoadas = horasVoadas;
		this.bagagem = bagagem;
	}
	
	
}
